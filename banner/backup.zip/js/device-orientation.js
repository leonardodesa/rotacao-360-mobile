'use strict';

(function () {
    // device
    // Create viewer.
   
})();